# Employee Payroll Management System

Student: Mohammed Affan
SRN: R24SA025
Program: B.Sc. (BSTCs), Semester V
University: REVA University
Subject: Java Programming

## Project
Console-based Employee Payroll Management System using Java OOP.

## Packages
- com.reva.payroll.model
- com.reva.payroll.service
- com.reva.payroll

## Compile
From the project root:

javac -d out src/com/reva/payroll/model/*.java src/com/reva/payroll/service/*.java src/com/reva/payroll/Main.java

## Run
java -cp out com.reva.payroll.Main

## Salary rules used
Permanent:
Gross = Basic + 20% HRA + 10% DA
PF = 12% of basic
Tax = 10% of gross when gross > Rs. 50,000

Contract:
Gross = Basic + 15% HRA + 5% DA
Professional tax = Rs. 200

Part-Time:
Gross = Hourly rate × Hours worked
Deduction = 5% of gross

These are project demonstration rules and are not intended to represent an actual company's payroll policy.
